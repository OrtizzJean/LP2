﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade_8
{
    public partial class frm4 : Form
    {
        public frm4()
        {
            InitializeComponent();
        }

        private void lstbxNomes_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] vetor = new string[2];
            int[] vetor2 = new int[2];

            string auxiliar;

            for (int i = 0; i < 2; i++)
            {
                auxiliar = Interaction.InputBox("Digite o nome.", "Entrada de Dados");

                if (auxiliar.Replace(" ", " ").Length == 0)
                {

                    MessageBox.Show("Valor Inválido");
                    i--;

                }
                else
                {
                    vetor[i] = auxiliar;
                    vetor2[i] = auxiliar.Replace(' ', '_').Length;
                }

            }
            for (int i = 0; i < 2; i++)
            {
                lstbxNomes.Items.Add($"O nome {vetor[i]} tem {vetor2[i]} caracteres");
            }











            }
        }
}
