﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PFerramentas0030482423021
{
    public partial class frmFabricante : Form
    {
        private BindingSource bnFabricante = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsFabricante = new DataSet();
        public frmFabricante()
        {
            InitializeComponent();
        }



        private void frmFabricante_Load(object sender, EventArgs e)
        {
            try
            {
                Fabricante RegCat = new Fabricante();
                dsFabricante.Tables.Add(RegCat.Listar());
                bnFabricante.DataSource = dsFabricante.Tables["FABRICANTE"];
                dgvFabricante.DataSource = bnFabricante;
                bnvFabricante.BindingSource = bnFabricante;

                txtId.DataBindings.Add("TEXT", bnFabricante, "ID");
                txtNome.DataBindings.Add("TEXT", bnFabricante, "NOMEFANTASIA");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnNovoRegistro_Click_1(object sender, EventArgs e)
        {
            if (tbFabricante.SelectedIndex == 0)
            {
                tbFabricante.SelectTab(1);
            }

            bnFabricante.AddNew();
            txtNome.Enabled = false;
            txtNome.Focus();
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovoRegistro.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = true;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            bnFabricante.CancelEdit();
            txtNome.Enabled = true;
            btnAlterar.Enabled = true;
            btnNovoRegistro.Enabled = false;
            btnSalvar.Enabled = false;
            btnExcluir.Enabled = true;
            btnCancelar.Enabled = false;
            bInclusao = false;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        

        private void btnExcluir_Click_1(object sender, EventArgs e)
        {
            if (tbFabricante.SelectedIndex == 0)
            {
                tbFabricante.SelectTab(1);
            }

            if (MessageBox.Show("Confirma exclusão?", "YES or NO", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Categoria RegCat = new Categoria();
                RegCat.IdCategoria = Convert.ToInt16(txtId.Text);

                if (RegCat.Excluir() > 0)
                {
                    MessageBox.Show("Categoria excluída com sucesso!");

                    Categoria R = new Categoria();
                    dsFabricante.Tables.Clear();
                    dsFabricante.Tables.Add(R.Listar());
                    bnFabricante.DataSource = dsFabricante.Tables["CATEGORIA"];
                }
                else
                {
                    MessageBox.Show("Erro ao excluir categoria!");
                }
            }
        }

        private void btnAlterar_Click_1(object sender, EventArgs e)
        {
            if (tbFabricante.SelectedIndex == 0)
            {
                tbFabricante.SelectTab(1);
            }


            txtNome.Enabled = true;
            txtNome.Focus();
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovoRegistro.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = false;
        }

        private void btnSalvar_Click_1(object sender, EventArgs e)
        {
            //validar os dados
            if (txtNome.Text == "" || txtNome.Text.Replace(" ", "").Length < 5)
            {
                MessageBox.Show("Categoria inválida");
            }
            else
            {
                Categoria RegCat = new Categoria();
                RegCat.IdCategoria = Convert.ToInt32(txtNome.Text);
                RegCat.Descricao = txtNome.Text;
                if (bInclusao)
                {
                    if (RegCat.Salvar() > 0)
                    {
                        MessageBox.Show("Categoria adicionada com sucesso!");

                        txtId.Enabled = false;
                        txtNome.Enabled = false;
                        btnSalvar.Enabled = true;
                        btnAlterar.Enabled = true;
                        btnNovoRegistro.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;

                        bInclusao = false;

                        //recarrega o grid 
                        dsFabricante.Tables.Clear();
                        dsFabricante.Tables.Add(RegCat.Listar());
                        bnFabricante.DataSource = dsFabricante.Tables["CATEGORIA"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar a categoria!");
                    }
                }
                else //ALTERAÇÃO
                {
                    if (RegCat.Alterar() > 0)
                    {
                        MessageBox.Show("Categoria adicionada com sucesso!");

                        txtId.Enabled = false;
                        txtNome.Enabled = false;
                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovoRegistro.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;

                        bInclusao = false;

                        //recarrega o grid 
                        dsFabricante.Tables.Clear();
                        dsFabricante.Tables.Add(RegCat.Listar());
                        bnFabricante.DataSource = dsFabricante.Tables["CATEGORIA"];
                    }
                }
            }
        }
    }
}
