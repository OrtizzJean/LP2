﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PFerramentas0030482423021
{
    public partial class frmFerramenta : Form
    {
        private BindingSource bnFerramenta = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsFerramenta = new DataSet();
        private DataSet dsCategoria = new DataSet();
        private DataSet dsFabricante = new DataSet();

        public frmFerramenta()
        {
            InitializeComponent();
        }

        private void frmFerramenta_Load(object sender, EventArgs e)
        {
            try
            {
                Ferramentas RegFerr = new Ferramentas();
                dsFerramenta.Tables.Add(RegFerr.Listar());
                bnFerramenta.DataSource = dsFerramenta.Tables["FERRAMENTA"];
                dgvFerramenta.DataSource = bnFerramenta;
                bnvFerramenta.BindingSource = bnFerramenta;

                txtIdFerramenta.DataBindings.Add("TEXT", bnFerramenta, "ID");
                txtNome.DataBindings.Add("TEXT", bnFerramenta, "nome");
                cbxDistribuicao.DataBindings.Add("SelectedItem", bnFerramenta, "distribuicao");
                dtpCadastro.DataBindings.Add("TEXT", bnFerramenta, "dtcadastro");
                txtSiteOficial.DataBindings.Add("TEXT", bnFerramenta, "siteoficial");

                // Carrega dados da categoria
                Categoria RegCat = new Categoria();
                dsCategoria.Tables.Add(RegCat.Listar());
                cbxCategoria.DataSource = dsCategoria.Tables["Categoria"];
                //campo que será mostrado para o usuario
                cbxCategoria.DisplayMember = "descricao";
                //campo que é a chave da tabela categoria e que liga com a tabela ferramenta
                cbxCategoria.ValueMember = "id";
                //No momento de linkar os componentes com o Binding Source linkar também
                cbxCategoria.DataBindings.Add("SelectedValue", bnFerramenta, "idCategoria");
                //ajustar dropdownstyle para dropdownlist para nao deixar digitar


                // Carrega dados do Fabricante
                Fabricante RegFab = new Fabricante();
                dsFabricante.Tables.Add(RegFab.Listar());
                cbxFabricante.DataSource = dsFabricante.Tables["Fabricante"];
                //campo que será mostrado para o usuario
                cbxFabricante.DisplayMember = "nomeFantasia";
                //campo que é a chave da tabela Fabricante e que liga com a tabela ferramenta
                cbxFabricante.ValueMember = "id";
                //No momento de linkar os componentes com o Binding Source linkar também
                cbxFabricante.DataBindings.Add("SelectedValue", bnFerramenta, "idFabricante");
                //ajustar dropdownstyle para dropdownlist para nao deixar digitar




            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnNovoRegistro_Click(object sender, EventArgs e)
        {
            if (tbFerramenta.SelectedIndex == 0)
            {
                tbFerramenta.SelectTab(1);

            }

            bnFerramenta.AddNew();
            txtNome.Enabled = true;
            txtNome.Focus();
            txtSiteOficial.Enabled = true;
            cbxDistribuicao.Enabled = true;
            dtpCadastro.Enabled = true;
            cbxCategoria.Enabled = true;
            cbxFabricante.Enabled = true;

            cbxCategoria.SelectedIndex = 0;
            cbxFabricante.SelectedIndex = 0;
            cbxDistribuicao.SelectedIndex = 0;

            btnNovoRegistro.Enabled = false;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;

            bInclusao = true;

        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (tbFerramenta.SelectedIndex == 0)
            {
                tbFerramenta.SelectTab(1);
            }
            if (MessageBox.Show("Confirma exclusão?", "Yes or No", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Ferramentas RegFerr = new Ferramentas();
                RegFerr.IdFerramenta = Convert.ToInt32(txtIdFerramenta.Text);

                if (RegFerr.Excluir() > 0)
                {
                    MessageBox.Show("Ferramenta excluída com sucesso!");

                    //recarrega o grid
                    dsFerramenta.Tables.Clear();
                    dsFerramenta.Tables.Add(RegFerr.Listar());
                    bnFerramenta.DataSource = dsFerramenta.Tables["Ferramenta"];
                }
                else
                {
                    MessageBox.Show("Erro ao excluir Ferramenta!");
                }
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (tbFerramenta.SelectedIndex == 0)
            {
                tbFerramenta.SelectTab(1);

            }

            txtNome.Enabled = true;
            txtSiteOficial.Enabled = true;
            cbxDistribuicao.Enabled = true;
            dtpCadastro.Enabled = true;
            cbxCategoria.Enabled = true;
            cbxFabricante.Enabled = true;

            btnNovoRegistro.Enabled = false;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;

            bInclusao = false;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (txtNome.Text == "" || (txtNome.Text.Replace(" ", "").Length < 1))
            {
                MessageBox.Show("Nome inválido");
            }
            else if (cbxDistribuicao.SelectedIndex == -1)
            {
                MessageBox.Show("Distribuição inválida!");
            }
            else if (txtSiteOficial.Text == "" || txtSiteOficial.Text.Replace(" ", "").Length < 8)
            {
                MessageBox.Show("Site oficial inválido!");
            }
            else if (Convert.ToDateTime(dtpCadastro.Value) < DateTime.Today)
            {
                MessageBox.Show("Data inválida!");
            }
            else if (cbxCategoria.SelectedIndex == -1)
            {
                MessageBox.Show("Categoria inválida!");
            }
            else if (cbxFabricante.SelectedIndex == -1)
            {
                MessageBox.Show("Fabricante inválido!");
            }
            else
            {
                Ferramentas RegFerr = new Ferramentas();
                RegFerr.Nome = txtNome.Text;
                RegFerr.Distribuicao = Convert.ToChar(cbxDistribuicao.SelectedItem);
                RegFerr.DtCadastro = dtpCadastro.Value;
                RegFerr.SiteOficial = txtSiteOficial.Text;
                RegFerr.IdCategoria = Convert.ToInt32(cbxCategoria.SelectedValue.ToString());
                RegFerr.IdFabricante = Convert.ToInt32(cbxFabricante.SelectedValue.ToString());

                if (bInclusao)
                {
                    if (RegFerr.Salvar() > 0)
                    {
                        MessageBox.Show("Ferramenta adicionada com sucesso!");

                        txtNome.Enabled = false;
                        txtSiteOficial.Enabled = false;
                        cbxDistribuicao.Enabled = false;
                        dtpCadastro.Enabled = false;
                        cbxCategoria.Enabled = false;
                        cbxFabricante.Enabled = false;

                        btnNovoRegistro.Enabled = true;
                        btnAlterar.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnSalvar.Enabled = false;
                        btnCancelar.Enabled = false;

                        bInclusao = false;
                        //Recarregar o grid

                        dsFerramenta.Tables.Clear();
                        dsFerramenta.Tables.Add(RegFerr.Listar());
                        bnFerramenta.DataSource = dsFerramenta.Tables["Ferramenta"];

                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar Ferramenta!");
                    }
                }
                else //alteração
                {
                    RegFerr.IdFerramenta = Convert.ToInt32(txtIdFerramenta.Text);

                    if(RegFerr.Alterar() > 0)
                    {
                        MessageBox.Show("Ferramenta alterada com sucesso!");

                        txtNome.Enabled = false;
                        txtSiteOficial.Enabled = false;
                        cbxDistribuicao.Enabled = false;
                        dtpCadastro.Enabled = false;
                        cbxCategoria.Enabled = false;
                        cbxFabricante.Enabled = false;

                        btnNovoRegistro.Enabled = true;
                        btnAlterar.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnSalvar.Enabled = false;
                        btnCancelar.Enabled = false;

                        bInclusao = false;
                        //Recarregar o grid

                        dsFerramenta.Tables.Clear();
                        dsFerramenta.Tables.Add(RegFerr.Listar());
                        bnFerramenta.DataSource = dsFerramenta.Tables["Ferramenta"];
                    }
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            bnFerramenta.CancelEdit();
            txtNome.Enabled = false;
            txtSiteOficial.Enabled = false;
            cbxDistribuicao.Enabled = false;
            dtpCadastro.Enabled = false;
            cbxCategoria.Enabled = false;
            cbxFabricante.Enabled = false;

            btnNovoRegistro.Enabled = true;
            btnAlterar.Enabled = true;
            btnExcluir.Enabled = true;
            btnSalvar.Enabled = false;
            btnCancelar.Enabled = false;

            bInclusao = false;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
