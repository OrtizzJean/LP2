﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        Double numero1, numero2, resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            txtNumero1.Clear(); 
            txtNumero2.Clear();
            txtResultado.Clear();
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            Close();
        }

        private void ButtonMais_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResultado.Text = resultado.ToString();
           
            
        }

        private void ButtonMenos_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void ButtonVezes_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void ButtonDiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("Não é possivel dividir por ZERO.");
                txtNumero2.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                txtResultado.Text = resultado.ToString();
            }
        }

        private void ButtonMais_Validated(object sender, EventArgs e)
        {

        }

        private void textBox1_Validated(object sender, EventArgs e)
        {

        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1))
                {
                MessageBox.Show("Número1 Inválido Cabeção");
                txtNumero1.Focus();

            }
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero2.Text, out numero2))
                {
                MessageBox.Show("Número2 Inválido Vacilão");
                txtNumero2.Focus();

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Double.TryParse(txtNumero1.Text, out numero1);
        }
    }
}
