﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PFerramentas0030482423021
{
    public partial class frmPrincipal : Form
    {


        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Data Source=Ortiz_DELL\\SQLEXPRESS;Initial Catalog=LP2;Integrated Security=True;");
                conexao.Open();

            }

            catch (SqlException ex)
            {
                MessageBox.Show("Erro de Banco de Dados = / " +ex.Message);

            }
            catch (Exception ex)
            {
                MessageBox.Show("Outro erros = / " +ex.Message);
            }
        
        
        }

        private void categoriasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmCategoria>().Count() > 0) 
            {
                Application.OpenForms["frmCategoria"].BringToFront();
            }
            else
            {
                frmCategoria FrmCategoria = new frmCategoria();
                FrmCategoria.MdiParent = this;
                FrmCategoria.WindowState = FormWindowState.Maximized;
                FrmCategoria.Show();
            }
        }

        private void fabricantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmFabricante>().Count() > 0)
            {
                Application.OpenForms["frmFabricante"].BringToFront();
            }
            else
            {
                frmFabricante frmFabricante = new frmFabricante();
                frmFabricante.MdiParent = this;
                frmFabricante.WindowState = FormWindowState.Maximized;
                frmFabricante.Show();
            }
        }

        private void ferramentasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmFerramenta>().Count() > 0)
            {
                Application.OpenForms["frmFerramenta"].BringToFront();
            }
            else
            {
                frmFerramenta frmFerramenta = new frmFerramenta();
                frmFerramenta.MdiParent = this;
                frmFerramenta.WindowState = FormWindowState.Maximized;
                frmFerramenta.Show();
            }
        }
    }
}
