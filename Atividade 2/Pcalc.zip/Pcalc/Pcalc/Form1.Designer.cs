﻿namespace Pcalc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.ButtonDiv = new System.Windows.Forms.Button();
            this.ButtonMenos = new System.Windows.Forms.Button();
            this.ButtonVezes = new System.Windows.Forms.Button();
            this.ButtonMais = new System.Windows.Forms.Button();
            this.ButtonLimpar = new System.Windows.Forms.Button();
            this.ButtonSair = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNumero1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNumero2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // ButtonDiv
            // 
            this.ButtonDiv.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonDiv.Location = new System.Drawing.Point(569, 299);
            this.ButtonDiv.Name = "ButtonDiv";
            this.ButtonDiv.Size = new System.Drawing.Size(148, 148);
            this.ButtonDiv.TabIndex = 3;
            this.ButtonDiv.Text = "/";
            this.ButtonDiv.UseVisualStyleBackColor = true;
            this.ButtonDiv.Click += new System.EventHandler(this.ButtonDiv_Click);
            // 
            // ButtonMenos
            // 
            this.ButtonMenos.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonMenos.Location = new System.Drawing.Point(209, 299);
            this.ButtonMenos.Name = "ButtonMenos";
            this.ButtonMenos.Size = new System.Drawing.Size(148, 148);
            this.ButtonMenos.TabIndex = 6;
            this.ButtonMenos.Text = "-";
            this.ButtonMenos.UseVisualStyleBackColor = true;
            this.ButtonMenos.Click += new System.EventHandler(this.ButtonMenos_Click);
            // 
            // ButtonVezes
            // 
            this.ButtonVezes.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonVezes.Location = new System.Drawing.Point(384, 299);
            this.ButtonVezes.Name = "ButtonVezes";
            this.ButtonVezes.Size = new System.Drawing.Size(148, 148);
            this.ButtonVezes.TabIndex = 7;
            this.ButtonVezes.Text = "*";
            this.ButtonVezes.UseVisualStyleBackColor = true;
            this.ButtonVezes.Click += new System.EventHandler(this.ButtonVezes_Click);
            // 
            // ButtonMais
            // 
            this.ButtonMais.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonMais.Location = new System.Drawing.Point(23, 299);
            this.ButtonMais.Name = "ButtonMais";
            this.ButtonMais.Size = new System.Drawing.Size(148, 148);
            this.ButtonMais.TabIndex = 8;
            this.ButtonMais.Text = "+\r\n";
            this.ButtonMais.UseVisualStyleBackColor = true;
            this.ButtonMais.Click += new System.EventHandler(this.ButtonMais_Click);
            this.ButtonMais.Validated += new System.EventHandler(this.ButtonMais_Validated);
            // 
            // ButtonLimpar
            // 
            this.ButtonLimpar.Location = new System.Drawing.Point(576, 29);
            this.ButtonLimpar.Name = "ButtonLimpar";
            this.ButtonLimpar.Size = new System.Drawing.Size(141, 71);
            this.ButtonLimpar.TabIndex = 9;
            this.ButtonLimpar.Text = "Limpar";
            this.ButtonLimpar.UseVisualStyleBackColor = true;
            this.ButtonLimpar.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // ButtonSair
            // 
            this.ButtonSair.Location = new System.Drawing.Point(576, 137);
            this.ButtonSair.Name = "ButtonSair";
            this.ButtonSair.Size = new System.Drawing.Size(141, 114);
            this.ButtonSair.TabIndex = 10;
            this.ButtonSair.Text = "Sair";
            this.ButtonSair.UseVisualStyleBackColor = true;
            this.ButtonSair.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(28, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 46);
            this.label1.TabIndex = 11;
            this.label1.Text = "Numero 1";
            // 
            // txtNumero1
            // 
            this.txtNumero1.Location = new System.Drawing.Point(268, 39);
            this.txtNumero1.Multiline = true;
            this.txtNumero1.Name = "txtNumero1";
            this.txtNumero1.Size = new System.Drawing.Size(251, 39);
            this.txtNumero1.TabIndex = 12;
            this.txtNumero1.Validated += new System.EventHandler(this.txtNumero1_Validated);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(28, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(195, 46);
            this.label2.TabIndex = 14;
            this.label2.Text = "Numero 2";
            // 
            // txtResultado
            // 
            this.txtResultado.Enabled = false;
            this.txtResultado.Location = new System.Drawing.Point(268, 190);
            this.txtResultado.Multiline = true;
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(251, 75);
            this.txtResultado.TabIndex = 15;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(28, 205);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(200, 46);
            this.label3.TabIndex = 16;
            this.label3.Text = "Resultado";
            // 
            // txtNumero2
            // 
            this.txtNumero2.Location = new System.Drawing.Point(268, 112);
            this.txtNumero2.Multiline = true;
            this.txtNumero2.Name = "txtNumero2";
            this.txtNumero2.Size = new System.Drawing.Size(251, 39);
            this.txtNumero2.TabIndex = 17;
            this.txtNumero2.Validated += new System.EventHandler(this.txtNumero2_Validated);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(756, 483);
            this.Controls.Add(this.txtNumero2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtNumero1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ButtonSair);
            this.Controls.Add(this.ButtonLimpar);
            this.Controls.Add(this.ButtonMais);
            this.Controls.Add(this.ButtonVezes);
            this.Controls.Add(this.ButtonMenos);
            this.Controls.Add(this.ButtonDiv);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ButtonDiv;
        private System.Windows.Forms.Button ButtonMenos;
        private System.Windows.Forms.Button ButtonVezes;
        private System.Windows.Forms.Button ButtonMais;
        private System.Windows.Forms.Button ButtonLimpar;
        private System.Windows.Forms.Button ButtonSair;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNumero1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtResultado;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNumero2;
    }
}

