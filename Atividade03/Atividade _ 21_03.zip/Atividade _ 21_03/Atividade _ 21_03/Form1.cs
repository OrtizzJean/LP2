﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade___21_03
{
    public partial class Form1 : Form
    {
        double pesoAtual;
        double altura;
        double imc;

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }


        private void mskbxPeso_Validated_1(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxPeso.Text, out pesoAtual))
            {
                MessageBox.Show("Dado inválido.");
                Focus();
                mskbxAltura.Clear();
                mskbxPeso.Clear();

            }
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(mskbxAltura.Text, out altura))
            {
                MessageBox.Show("Dado inválido.");
                Focus();
                mskbxAltura.Clear();
                mskbxPeso.Clear();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
          imc = pesoAtual/ Math.Pow(altura, 2);
          imc = Math.Round(imc,1);
          txtBoxIMC.Text = imc.ToString();


            if (imc <= 18.5)
                MessageBox.Show("Magreza.");

            else if (imc <= 24.9)
                MessageBox.Show("Normal.");

            else if (imc <= 29.9)
                MessageBox.Show("Sobrepeso.");
            else if (imc <= 39.9)
                MessageBox.Show("Obesidade.");
            else
                MessageBox.Show("Obesidade Grave.");
                                {
              
                    
           

                  
                }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
            txtBoxIMC.Clear();
        }
    }
}