﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pvestibular01
{
    public partial class Form1 : Form
    {



        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnDados_Click(object sender, EventArgs e)
        {

            int[,] matriz = new int[3, 5];
            int curso;
            int ano;

            

            MessageBox.Show("Digite o curso: " +curso);
            MessageBox.Show("Digite o ano: " +ano);

            

            for (int i = 0; i < matriz.GetLength; i++)
            {
                for (int j = 0; j < matriz.GetLength(5); j++)
                {
                    curso++;
                    ano++;
                    MessageBox.Show(curso + ano);
                }
            }
;
                



        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
           
        }
    }
}
