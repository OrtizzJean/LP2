﻿namespace PFerramentas0030482423021
{
    partial class frmSobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSobre));
            this.lblSobreDesc = new System.Windows.Forms.Label();
            this.lblViniDesc = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblVini = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblSobre = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblSobreDesc
            // 
            this.lblSobreDesc.AutoSize = true;
            this.lblSobreDesc.BackColor = System.Drawing.Color.Transparent;
            this.lblSobreDesc.Font = new System.Drawing.Font("Georgia", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSobreDesc.ForeColor = System.Drawing.Color.Gold;
            this.lblSobreDesc.Location = new System.Drawing.Point(12, 104);
            this.lblSobreDesc.Name = "lblSobreDesc";
            this.lblSobreDesc.Size = new System.Drawing.Size(393, 96);
            this.lblSobreDesc.TabIndex = 3;
            this.lblSobreDesc.Text = resources.GetString("lblSobreDesc.Text");
            // 
            // lblViniDesc
            // 
            this.lblViniDesc.AutoSize = true;
            this.lblViniDesc.BackColor = System.Drawing.Color.Transparent;
            this.lblViniDesc.Font = new System.Drawing.Font("Georgia", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViniDesc.ForeColor = System.Drawing.Color.Gold;
            this.lblViniDesc.Location = new System.Drawing.Point(201, 326);
            this.lblViniDesc.Name = "lblViniDesc";
            this.lblViniDesc.Size = new System.Drawing.Size(193, 112);
            this.lblViniDesc.TabIndex = 4;
            this.lblViniDesc.Text = "Programador iniciante, \r\nestudante de ADS na FATEC.\r\nAmante de games, carros \r\nan" +
    "tigos e tecnologias no geral.\r\nDe preferência, combinando \r\ntodos ao mesmo tempo" +
    "!\r\n\r\n";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::PFerramentas0030482423021.Properties.Resources.Foto_selecionada;
            this.pictureBox3.Location = new System.Drawing.Point(411, 230);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(163, 208);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::PFerramentas0030482423021.Properties.Resources.shared_image;
            this.pictureBox2.Location = new System.Drawing.Point(12, 230);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(163, 208);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PFerramentas0030482423021.Properties.Resources.Mídia;
            this.pictureBox1.Location = new System.Drawing.Point(411, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(163, 208);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lblVini
            // 
            this.lblVini.AutoSize = true;
            this.lblVini.BackColor = System.Drawing.Color.Transparent;
            this.lblVini.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVini.ForeColor = System.Drawing.Color.Gold;
            this.lblVini.Location = new System.Drawing.Point(216, 230);
            this.lblVini.Name = "lblVini";
            this.lblVini.Size = new System.Drawing.Size(141, 75);
            this.lblVini.TabIndex = 5;
            this.lblVini.Text = "Vinicius \r\n   Romera \r\n      Carvalho\r\n";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(640, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 50);
            this.label1.TabIndex = 7;
            this.label1.Text = "Jean \r\n   Ortiz \r\n";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Georgia", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gold;
            this.label2.Location = new System.Drawing.Point(593, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(200, 80);
            this.label2.TabIndex = 6;
            this.label2.Text = "Programador iniciante,\r\nestudante de ADS na FATEC.\r\nCinéfilo, Corinthiano sofredo" +
    "r \r\ne adepto ao movimento contra \r\no escanteio curto.\r\n";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gold;
            this.label3.Location = new System.Drawing.Point(622, 248);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(141, 75);
            this.label3.TabIndex = 9;
            this.label3.Text = "Daniel \r\n     Pedro \r\n      de Souza\r\n";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Georgia", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gold;
            this.label4.Location = new System.Drawing.Point(593, 358);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(182, 80);
            this.label4.TabIndex = 8;
            this.label4.Text = "Programador iniciante, \r\nestudante de ADS na FATEC.\r\nInteressado em robótica e\r\nc" +
    "ansado.\r\n\r\n";
            // 
            // lblSobre
            // 
            this.lblSobre.AutoSize = true;
            this.lblSobre.BackColor = System.Drawing.Color.Transparent;
            this.lblSobre.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSobre.ForeColor = System.Drawing.Color.Gold;
            this.lblSobre.Location = new System.Drawing.Point(12, 9);
            this.lblSobre.Name = "lblSobre";
            this.lblSobre.Size = new System.Drawing.Size(289, 62);
            this.lblSobre.TabIndex = 10;
            this.lblSobre.Text = "Informações sobre \r\na aplicação: ";
            // 
            // frmSobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PFerramentas0030482423021.Properties.Resources.OIP__1_;
            this.ClientSize = new System.Drawing.Size(805, 450);
            this.Controls.Add(this.lblSobre);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblVini);
            this.Controls.Add(this.lblViniDesc);
            this.Controls.Add(this.lblSobreDesc);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "frmSobre";
            this.Text = "frmSobre";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label lblSobreDesc;
        private System.Windows.Forms.Label lblViniDesc;
        private System.Windows.Forms.Label lblVini;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblSobre;
    }
}