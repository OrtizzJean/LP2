﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade_8
{
    public partial class Frm5 : Form
    {
        public Frm5()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            String[,] Alunos = new String[2, 10];
            string[] Gabarito = new string[5];
            Gabarito = new string[10] { "A", "A", "A", "A", "A", "A", "A", "A", "A", "A"};

            string auxiliar = "";

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a resposta do aluno {i + 1} para a questão {j + 1}:");
                    if (auxiliar.Replace(" ", "").Length == 0 || !"ABCDE".Contains(auxiliar.ToUpper()))
                    {
                        MessageBox.Show("Valor inválido!");
                        j--;
                    }
                    else
                    {
                        Alunos[i, j] = auxiliar.ToUpper();
                    }
                }
            }

            

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (Alunos[i, j].ToUpper() == Gabarito[j].ToString())
                    {
                        
                        lstbxNomes.Items.Add($"O aluno: {i + 1} acertou a questão {j + 1}: Era: " + Gabarito[j] + " | Escolheu: " + Alunos[i, j]);

                    }
                    else
                    {
                        
                        lstbxNomes.Items.Add($"O aluno: {i + 1}   errou   a questão {j + 1}: Era: " + Gabarito[j] + " | Escolheu: " + Alunos[i, j]);
                    }
                }
            }
        }
        }
    }
    




            